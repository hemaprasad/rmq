/**
 * 
 */
package com.dell.eis.it.pool;

import org.springframework.amqp.rabbit.core.RabbitOperations;

/**
 * @author Vinay Yadav
 *
 */
public class ConnectionStamp {
	
	private RabbitOperations rabbitOperations;
	private boolean isRunning=false;
	private static volatile int  holdCount=0;
	
	
	public ConnectionStamp(RabbitOperations rabbitOperations, boolean isRunning) {
		super();
		this.rabbitOperations = rabbitOperations;
		this.isRunning = isRunning;
	}
	
	
	public RabbitOperations getRabbitOperations() {
		return rabbitOperations;
	}
	public void setRabbitOperations(RabbitOperations rabbitOperations) {
		this.rabbitOperations = rabbitOperations;
	}
	public boolean isRunning() {
		return isRunning;
	}
	public void setRunning(boolean isRunning) {
		this.isRunning = isRunning;
	}
	
	public void increaseHold()
	{
		holdCount++;
	}
	
	public void decreaseHold()
	{
		holdCount--;
	}

	public int getHoldCount() {
		return holdCount;
	}
	
	

}
