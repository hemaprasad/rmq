/**
 * 
 */
package com.dell.eis.it.pool;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

/**
 * @author Vinay Yadav
 *
 */

@Component
public class ConnectionPool {
	
	
	private Map<Integer, List<ConnectionStamp>> connectionMap;
	
	ConnectionPool()
	{
		connectionMap= new HashMap<Integer, List<ConnectionStamp>>();
	}
	
	public void addConnection(int connId,List<ConnectionStamp> conStamps)
	{
		if(!connectionMap.containsKey(connId))
		{
			connectionMap.put(connId, conStamps);
		}
		else
		{
			System.out.println("Duplicate connection Id ..!");
		}
		
	}
	
	public List<ConnectionStamp> getConnection(int connId)
	{
		if(connectionMap.containsKey(connId))
		{
			return connectionMap.get(connId);
		}
		else
		{
			System.out.println("Duplicate connection Id ..!");
			return null;
		}
		
	}
	
	
	
	public boolean isConnectionIdExist(int connId)
	{
		return connectionMap.containsKey(connId);
	}

}
