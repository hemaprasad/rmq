/**
 * 
 */
package com.dell.eis.it.service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.dell.eis.it.pool.ConnectionPool;
import com.dell.eis.it.pool.ConnectionStamp;

/**
 * @author Vinay Yadav
 *
 */

@Component
public class RabbitConsumer {

	@Autowired
	private ConnectionPool conPool;
	
	@Value("${rmq.service.max.message.count}")
	private int messageCount;
	
	public List<String>  consumeMessage(int connId)
	{
		ConnectionStamp conStamp=conPool.getConnection(connId).parallelStream().min(Comparator.comparing(ConnectionStamp::getHoldCount)).orElseThrow(NoSuchElementException::new);
		
		RabbitTemplate template=(RabbitTemplate) conStamp.getRabbitOperations();
		
		conStamp.increaseHold();	
		
		List<String> messages= new ArrayList<String>();
		
				for(int i=0;i<messageCount;i++)
				{
					Object obj=template.receiveAndConvert();
					if(obj!=null)
						messages.add(obj.toString());
					else
						break;
					
					
				}
				
				conStamp.decreaseHold();
				
		return messages;
		
	}
	
}
