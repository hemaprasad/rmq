/**
 * 
 */
package com.dell.eis.it.model;

import java.util.List;

/**
 * @author Vinay Yadav
 *
 */
public class PayLoadInfo {
	
	private String SalesOrderId;
	private String ProdOrderNum;
	private String Buid;
	private String StatusCode;
	private List<OrderTies> OrderTies;
	
	
	
}
