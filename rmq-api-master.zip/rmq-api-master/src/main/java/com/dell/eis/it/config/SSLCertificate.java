/**
 * 
 */
package com.dell.eis.it.config;

import java.security.KeyStore;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;

import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import com.dell.eis.it.exception.MessageOverSizeException;

/**
 * @author Vinay Yadav
 *
 */
@Component
public class SSLCertificate {
	
	@Bean
	public SSLContext getSSLContext()
	{
		try {
			
		
	      char[] trustPassphrase = "password1".toCharArray();
	      
	      KeyStore tks = KeyStore.getInstance("JKS");
	      
	      tks.load(getClass().getResourceAsStream("/key2.jks"), trustPassphrase);

	      TrustManagerFactory tmf = TrustManagerFactory.getInstance("SunX509");
	      tmf.init(tks);

	      SSLContext c = SSLContext.getInstance("TLSv1.2");
	     
	      c.init(null, tmf.getTrustManagers(), null);
	     
	      return c;
	      
		}
		catch (Exception e) {
			
			System.out.println("Inside the Exception to load the key...");
			
			throw new MessageOverSizeException("Exception to laod the TLS Key..!");
		}
		
	}
	

}
