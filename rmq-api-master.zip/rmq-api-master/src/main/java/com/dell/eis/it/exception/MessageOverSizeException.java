/**
 * 
 */
package com.dell.eis.it.exception;

/**
 * @author Vinay Yadav
 *
 */
public class MessageOverSizeException  extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MessageOverSizeException(String message) {
		super(message);
		
	}

	
	

}
