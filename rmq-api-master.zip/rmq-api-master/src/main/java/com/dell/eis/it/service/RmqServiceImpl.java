/**
 * 
 */
package com.dell.eis.it.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author Vinay Yadav
 *
 */

@Service
public class RmqServiceImpl implements RmqService{

	@Autowired
	private RabbitProducer producer;
	
	@Autowired
	private RabbitConsumer consumer;
	
	public String produceMessage(int connId, List<String> messages) {
		
		return producer.produceMessage(connId, messages);
	}

	
	public List<String> consumeMessage(int connId) {
		
			return consumer.consumeMessage(connId);
		}

	
}
