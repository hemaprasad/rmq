/**
 * 
 */
package com.dell.eis.it.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author Vinay Yadav
 *
 */

@SpringBootApplication(scanBasePackages="com.dell.eis.it")
public class RMQService {

	
	public static void main(String[] args) {
		 SpringApplication.run(RMQService.class, args);

	}
	
}
