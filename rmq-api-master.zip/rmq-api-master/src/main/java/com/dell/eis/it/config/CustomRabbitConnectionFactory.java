package com.dell.eis.it.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitOperations;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.dell.eis.it.model.ConfigInfo;

/**
 * @author Vinay Yadav
 *
 */
@Component
public class CustomRabbitConnectionFactory {

	private static final Logger logger = LoggerFactory.getLogger(CustomRabbitConnectionFactory.class);
	
	@Autowired
	private SSLCertificate certficate;
	
	
	private CachingConnectionFactory connectionFactory(ConfigInfo config) {

		CachingConnectionFactory connectionFactory=null;
			
			try {
				
				connectionFactory = new CachingConnectionFactory();
				
				
				if(certficate.getSSLContext()!=null && config.getIsTLSEnable()!=null && config.getIsTLSEnable().equalsIgnoreCase("YES"))
				{
					connectionFactory.getRabbitConnectionFactory().useSslProtocol(certficate.getSSLContext());
					
					System.out.println("Trusted ...");
				}
					
				
				connectionFactory.setHost(config.getHost());
				connectionFactory.setPort(config.getPort());
				connectionFactory.setUsername(config.getUserName());
				connectionFactory.setPassword(config.getPassword());
				connectionFactory.setVirtualHost(config.getVirtualHost());
				connectionFactory.getRabbitConnectionFactory().setAutomaticRecoveryEnabled(true);
				
				
				return connectionFactory;
				
			}catch (Exception ex ) {
				logger.error("Unabe to connect with Host ");
				ex.printStackTrace();
			}
			
			return connectionFactory;
	}

	 public RabbitOperations rabbitOperations(ConfigInfo info) {
	    	
		 	
	        RabbitTemplate rabbitTemplate = new RabbitTemplate();
	        
	        rabbitTemplate.setConnectionFactory(connectionFactory(info));
	        rabbitTemplate.setQueue(info.getQueueName());
	        rabbitTemplate.setRoutingKey(info.getQueueName());
	        
	        return rabbitTemplate;
	    }
	
	
}
