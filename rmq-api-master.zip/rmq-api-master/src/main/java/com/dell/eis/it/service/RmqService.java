/**
 * 
 */
package com.dell.eis.it.service;

import java.util.List;

/**
 * @author Vinay Yadav
 *
 */
public interface RmqService {

	String produceMessage(int connId,List<String> messages);
	List<String> consumeMessage(int connId);
}
