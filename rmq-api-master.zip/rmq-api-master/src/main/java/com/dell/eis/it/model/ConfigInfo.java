package com.dell.eis.it.model;

/**
 * @author Vinay Yadav
 *
 */


public class ConfigInfo {

	
	private String host;
	private Integer port;
	private String queueName;
	private String userName;
	private String password;
	private String virtualHost;
	private String isTLSEnable;
	
	
	
	public ConfigInfo() {
		super();
		
	}



	public ConfigInfo(String host, Integer port, String queueName, String userName, String password, String virtualHost,
			String isTLSEnable) {
		super();
		this.host = host;
		this.port = port;
		this.queueName = queueName;
		this.userName = userName;
		this.password = password;
		this.virtualHost = virtualHost;
		this.isTLSEnable = isTLSEnable;
	}
	
	
	
	public String getHost() {
		return host;
	}
	public void setHost(String host) {
		this.host = host;
	}
	public Integer getPort() {
		return port;
	}
	public void setPort(Integer port) {
		this.port = port;
	}
	public String getQueueName() {
		return queueName;
	}
	public void setQueueName(String queueName) {
		this.queueName = queueName;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getVirtualHost() {
		return virtualHost;
	}
	public void setVirtualHost(String virtualHost) {
		this.virtualHost = virtualHost;
	}
	public String getIsTLSEnable() {
		return isTLSEnable;
	}
	public void setIsTLSEnable(String isTLSEnable) {
		this.isTLSEnable = isTLSEnable;
	}
	
	
	
	
	
}
