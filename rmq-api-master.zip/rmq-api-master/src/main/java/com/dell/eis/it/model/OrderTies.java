/**
 * 
 */
package com.dell.eis.it.model;

/**
 * @author Vinay Yadav
 *
 */
public class OrderTies {
		
	private int TieNumber;
	private String SystemIntegrationNumber;
	private String SkuNumber;
	private String CSWFStatus;
	private String TDStatus;
	private String StatusDate;
	
	
	
	

	public OrderTies() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getTieNumber() {
		return TieNumber;
	}

	public void setTieNumber(int tieNumber) {
		TieNumber = tieNumber;
	}

	public String getSystemIntegrationNumber() {
		return SystemIntegrationNumber;
	}

	public void setSystemIntegrationNumber(String systemIntegrationNumber) {
		SystemIntegrationNumber = systemIntegrationNumber;
	}

	public String getSkuNumber() {
		return SkuNumber;
	}

	public void setSkuNumber(String skuNumber) {
		SkuNumber = skuNumber;
	}

	public String getCSWFStatus() {
		return CSWFStatus;
	}

	public void setCSWFStatus(String cSWFStatus) {
		CSWFStatus = cSWFStatus;
	}

	public String getTDStatus() {
		return TDStatus;
	}

	public void setTDStatus(String tDStatus) {
		TDStatus = tDStatus;
	}

	public String getStatusDate() {
		return StatusDate;
	}

	public void setStatusDate(String statusDate) {
		StatusDate = statusDate;
	}
	
	
	
	
	
	
}
