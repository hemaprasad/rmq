/**
 * 
 */
package com.dell.eis.it.exception;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.dell.eis.it.model.ErrorMessage;


/**
 * @author Vinay Yadav
 *
 */
@ControllerAdvice
public class CustomExceptionHandler  extends ResponseEntityExceptionHandler{

	@Value("${rmq.message.max.size}")
	private int maxSizeInMB;
	
	@ExceptionHandler(Exception.class)
	public final ResponseEntity<ErrorMessage> handleMALException(Exception ex, WebRequest request) {
		
		ErrorMessage error= new ErrorMessage("Exception : unable to process ..!",ex.getMessage());
		ResponseEntity<ErrorMessage> response= new ResponseEntity<ErrorMessage>(error,new HttpHeaders(),HttpStatus.UNPROCESSABLE_ENTITY);
		
		return response;
	}
	
	@ExceptionHandler(MessageOverSizeException.class)
	public final ResponseEntity<ErrorMessage> handleOverSizeException(Exception ex, WebRequest request) {
		 
		ErrorMessage error= new ErrorMessage(" PayLoad Size should not be greater then " + maxSizeInMB +" MB ",ex.getMessage());
		ResponseEntity<ErrorMessage> response= new ResponseEntity<ErrorMessage>(error,new HttpHeaders(),HttpStatus.BAD_REQUEST);
		
		return response;
	}
	
}
