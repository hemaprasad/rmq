/**
 * 
 */
package com.dell.eis.it.config;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.dell.eis.it.model.ConfigInfo;
import com.dell.eis.it.pool.ConnectionPool;
import com.dell.eis.it.pool.ConnectionStamp;

/**
 * @author Vinay Yadav
 *
 */
@Component
public class InitialConfiguration {
	
	@Autowired
	private Environment env;
	
	@Autowired
	private ConnectionPool pool;
	
	@Autowired
	private CustomRabbitConnectionFactory connectionFactory;
	
	@Value("${rmq.service.con.size}")
	private int configLength;

	
	
	@PostConstruct
	public void  init()
	{
		
		System.out.println(" Load connection ...!");
		
		String prefixe="spring.rabbitmq.conf";
		String host="";
		String port="";
		String virtualHost="";
		
		String queueName="";
		String userName="";
		String password="";
		
		String isTLSEnable="";
		
		//String connId="";
		
		ConfigInfo info ;
		
		List <ConnectionStamp> conStamps= new ArrayList<ConnectionStamp>();
		
		for(int i=1;i<=configLength;i++)
		{
			
			host=prefixe+".host";
			port=prefixe+".port";
			virtualHost=prefixe+".virtual-host";
			queueName=prefixe+".queue-name";
			userName=prefixe+".username";
			password=prefixe+".password";
			
			//connId=prefixe+".conid";
			
			isTLSEnable=prefixe+".istlsenable";
			
			info= new ConfigInfo(env.getProperty(host), Integer.valueOf(env.getProperty(port)), env.getProperty(queueName), env.getProperty(userName), env.getProperty(password), env.getProperty(virtualHost), env.getProperty(isTLSEnable));
			
			conStamps.add(new ConnectionStamp(connectionFactory.rabbitOperations(info), false));
			
			//pool.addConnection(Integer.valueOf(env.getProperty(connId)), connectionFactory.rabbitOperations(info));
			
		}
		
		pool.addConnection(1, conStamps);
		
		System.out.println("Total Connection "+conStamps.size());
		
	}
}
