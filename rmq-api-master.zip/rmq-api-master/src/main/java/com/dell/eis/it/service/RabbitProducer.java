/**
 * 
 */
package com.dell.eis.it.service;

import java.util.Comparator;
import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.dell.eis.it.pool.ConnectionPool;
import com.dell.eis.it.pool.ConnectionStamp;

/**
 * @author Vinay Yadav
 *
 */
@Component
public class RabbitProducer {
	
	@Autowired
	private ConnectionPool conPool;
	
	public String produceMessage(int connId,List<String> messages)
	{
	
		ConnectionStamp conStamp=conPool.getConnection(connId).parallelStream().min(Comparator.comparing(ConnectionStamp::getHoldCount)).orElseThrow(NoSuchElementException::new);
		
		RabbitTemplate template=(RabbitTemplate) conStamp.getRabbitOperations();
		
		conStamp.increaseHold();

		for(String msg:messages)
		{
		
			template.convertAndSend(msg);
		}
		
			
		conStamp.decreaseHold();	
		
		return "Success...!";
	
	}

}
