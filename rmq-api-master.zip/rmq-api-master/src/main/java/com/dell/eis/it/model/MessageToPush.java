/**
 * 
 */
package com.dell.eis.it.model;

import java.util.List;

/**
 * @author Vinay Yadav
 *
 */
public class MessageToPush {

	private List<String> messages;
	private int connid;
	
	
	public MessageToPush() {
		super();
	}
	
	
	public List<String> getMessages() {
		return messages;
	}
	public void setMessages(List<String> messages) {
		this.messages = messages;
	}


	public int getConnid() {
		return connid;
	}


	public void setConnid(int connid) {
		this.connid = connid;
	}
	
	
	
}
