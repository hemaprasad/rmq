/**
 * 
 */
package com.dell.eis.it.controller;

import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dell.eis.it.model.MessageToPush;
import com.dell.eis.it.pool.ConnectionPool;
import com.dell.eis.it.service.RmqService;

/**
 * @author Vinay Yadav
 *
 */

@RestController
@RequestMapping("/api")
public class RmqController {
	
	
	@Autowired
	private RmqService service;
	
	@Autowired
	private ConnectionPool pool;
	
	@PostMapping("/produce")
	public ResponseEntity<String> produceMessage(@RequestBody MessageToPush payLoad)
	{
		
		if(pool.isConnectionIdExist(payLoad.getConnid()))
		{
			String response=service.produceMessage(payLoad.getConnid(), payLoad.getMessages());
			return new ResponseEntity<String>(response,HttpStatus.OK);
		}
		else
			return new ResponseEntity<String>(" Connection Id is not existed ..! ",HttpStatus.BAD_REQUEST);
	}
	
	@GetMapping("/consume/{connid}")
	public ResponseEntity<List<String>> consumeMessage(@PathVariable("connid") int connId)
	{
		
		
		if(pool.isConnectionIdExist(connId))
		{
			List<String> response=service.consumeMessage(connId);
			return new ResponseEntity<List<String>>(response,HttpStatus.OK);
		}
		else
			return new ResponseEntity<List<String>>(Collections.singletonList(" Connection Id is not existed ..! "),HttpStatus.BAD_REQUEST);
			
	}

}
